<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;

class RolesAndUsersSeeder extends Seeder
{
    public function run()
    {
        // Crear usuarios de ejemplo

        User::firstOrCreate(
            ['email' => 'admin@example.com'],
            ['name' => 'Admin', 'password' => bcrypt('password')]
        );

        User::firstOrCreate(
            ['email' => 'docente@example.com'],
            ['name' => 'Docente', 'password' => bcrypt('password')]
        );

        User::firstOrCreate(
            ['email' => 'estudiante@example.com'],
            ['name' => 'Estudiante', 'password' => bcrypt('password')]
        );
    }
}
