;

<?php $__env->startSection('content'); ?>
  <div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-10 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e(isset($teacher)? 'Editar': 'Agregar Nuevo'); ?> Docente <?php echo e(isset($teacher)? 'con el Número: '.$teacher->teacher_num: ''); ?></h4>
                        <p class="card-description">
                            Asignar al docente un aula y asignatura.
                        </p>
                        <form class="forms-sample" action="<?php echo e(isset($teacher) ? '/teacher/update/'.$teacher->id : '/teacher/store'); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="first_name" class="col-sm-3 col-form-label">Primer Nombre</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="first_name" id="first_name" autofocus
                                                   placeholder="Primer Nombre" value="<?php echo e(isset($teacher)? $teacher->first_name: old('first_name')); ?>">
                                            <?php if($errors->has('first_name')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('first_name')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="surname" class="col-sm-3 col-form-label">Apellido</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="surname" id="surname"
                                                   placeholder="Apellido" value="<?php echo e(isset($teacher)? $teacher->surname: old('surname')); ?>">
                                            <?php if($errors->has('surname')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('surname')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="gender" class="col-sm-3 col-form-label">Género</label>
                                        <div class="col-sm-9">
                                            <select id="gender" name="gender" class="form-control form-control-sm">
                                                <?php if(isset($teacher->gender)): ?>
                                                    <option value="0" <?php echo e(($teacher->gender == 0)? 'selected': ''); ?>>Masculino</option>
                                                    <option value="1" <?php echo e(($teacher->gender == 1)? 'selected': ''); ?>>Femenino</option>
                                                <?php else: ?>
                                                    <option value="0">Masculino</option>
                                                    <option value="1">Femenino</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="birth_date" class="col-sm-3 col-form-label">Fecha de Nacimiento</label>
                                        <div class="col-sm-9">
                                            <input type="date" class="form-control" name="birth_date" id="birth_date" min="01/01/1950"
                                                   placeholder="dd/mm/yyyy" value="<?php echo e(isset($teacher)? $teacher->birth_date: old('birth_date')); ?>">
                                            <?php if($errors->has('birth_date')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('birth_date')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="phone_number" class="col-sm-3 col-form-label">Número de Teléfono</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="phone_number" id="phone_number"
                                                   placeholder="Ingrese el número de teléfono comenzando con 0" value="<?php echo e(isset($teacher)? $teacher->phone_number: old('phone_number')); ?>">
                                            <?php if($errors->has('phone_number')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('phone_number')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="email" class="col-sm-3 col-form-label">Correo Electrónico</label>
                                        <div class="col-sm-9">
                                            <input type="email" class="form-control" name="email" id="email"
                                                   placeholder="Correo Electrónico" value="<?php echo e(isset($teacher)? $teacher->email: old('email')); ?>">
                                            <?php if($errors->has('email')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('email')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label for="address" class="col-sm-1 col-form-label">Dirección</label>
                                        <div class="col-sm-11">
                                            <textarea type="text" style="resize: vertical;" rows="3" class="form-control" name="address" id="address"
                                                      placeholder="Dirección"><?php echo e(isset($teacher)? $teacher->address: old('address')); ?></textarea>
                                            <?php if($errors->has('address')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('address')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="photo" class="col-sm-3 col-form-label">Subir Foto</label>
                                        <div class="col-sm-9">
                                            <input type="file" class="form-control" name="photo" id="photo" placeholder="">
                                            <?php if($errors->has('photo')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('photo')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label class="col-sm-3 col-form-label">Vista Previa</label>
                                        <div class="col-sm-9">
                                            <div class="preview-image"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <button type="submit" class="btn btn-primary me-2">Guardar</button>
                            <a class="btn btn-light" href="/teacher">Cancelar</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <script type="text/javascript">
        $(document).ready(function (){
            //A way to form dependence between two dropboxs using ajax jquery.
            // Todo: ask for the differences between these ways and which one has better performance.
            $('#classroom').change(function (){
                if($(this).val() !== '') {
                    var classroomId = $(this).val();
                    getClassSubjects(classroomId);
                } else {
                    $('#subject').html('<option value="">Select a Subject</option>');
                }
            });
            //Another way to form dependence between two dropboxs using ajax jquery.
            /*$('#classroom').change(function (){
                if($(this).val() !== '')
                {
                    var classroomId = document.getElementById('classroom').value;
                    var dependent = $(this).data('dependent');
                    var _token = $('input[name="_token"]').val();
                    $.ajax({
                        
                        method:"POST",
                        data:{id:classroomId, _token:_token},
                        success:function(result)
                        {
                            $('#'+dependent).html(result);
                        }

                    });
                } else {
                    $('#subject').html('<option value="">Select a Subject</option>');
                }
            });*/
        });

        function getClassSubjects(classroomId) {
            const xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                if (this.readyState === 4 && this.status === 200) {
                    document.getElementById("subject").innerHTML =
                        this.responseText;
                }
            };
            xhttp.open("get", "ajax/fetchSubjects/" + classroomId);
            xhttp.send();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gestion1\resources\views/teacher/view.blade.php ENDPATH**/ ?>