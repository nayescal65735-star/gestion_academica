;

<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-md-12 grid-margin">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h4 class="font-weight-bold mb-0"> Panel de control</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-8 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Bienvenido a nuestro sistema de gestión academico.</h4>
                            <div class="media">
                                <i class="ti-agenda icon-md text-info d-flex align-self-start me-3"></i>
                                <div class="media-body">
                                    <p class="card-text"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <!-- content-wrapper ends -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gestion1\resources\views/dashboard.blade.php ENDPATH**/ ?>