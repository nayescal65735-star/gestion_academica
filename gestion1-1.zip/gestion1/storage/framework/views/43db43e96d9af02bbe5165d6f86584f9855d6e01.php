;

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabla de Aulas</h4>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nombre</th>
                                        <th>Descripción</th>
                                        
                                        <th>Cantidad de Estudiantes</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="py-1">
                                                <?php echo e($classroom->id); ?>

                                            </td>
                                            <td>
                                                <?php echo e($classroom->name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($classroom->description); ?>

                                            </td>
                                            
                                            
                                            <td style="text-align: center">
                                                <?php echo e($classroom->students->count()); ?>

                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <form action="/classroom/edit/<?php echo e($classroom->id); ?>" method="get">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-dark ti-pencil-alt btn-rounded">
                                                            Editar
                                                        </button>
                                                    </form>
                                                    <form action="/classroom/delete/<?php echo e($classroom->id); ?>" method="post">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <button onclick="return confirm('¿Está seguro de que desea eliminar esto?')" type="submit" class="btn btn-danger ti-trash btn-rounded">
                                                            Eliminar
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-center">
                            <?php echo $classrooms->links(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gestion1\resources\views/classroom/index.blade.php ENDPATH**/ ?>