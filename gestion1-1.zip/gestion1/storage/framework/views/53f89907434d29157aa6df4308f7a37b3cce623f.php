;

<?php $__env->startSection('content'); ?>
   <div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-10 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">
                            <?php echo e(isset($subject)? 'Editar': 'Añadir Nueva'); ?> Asignatura 
                            <?php echo e(isset($subject)? 'con el Código: '.$subject->subject_code: ''); ?>

                        </h4>
                        <p class="card-description"></p>

                        <form class="forms-sample" action="<?php echo e(isset($subject) ? '/subject/update/'.$subject->id : '/subject/store'); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <!-- Nombre de la asignatura -->
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-3 col-form-label">Nombre</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="name" id="name" autofocus
                                                   placeholder="Nombre" value="<?php echo e(isset($subject)? $subject->name: old('name')); ?>">
                                        </div>
                                    </div>
                                </div>

                                <!-- Semestre -->
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label for="semester" class="col-sm-3 col-form-label">Semestre</label>
                                    <div class="col-sm-9">
                                        <select id="semester" name="semester" class="form-control form-control-sm">
                                            <?php
                                                $semestres = [
                                                    0 => 'Primero',
                                                    1 => 'Segundo',
                                                    2 => 'Tercero',
                                                    3 => 'Cuarto',
                                                    4 => 'Quinto',
                                                    5 => 'Sexto',
                                                    6 => 'Séptimo',
                                                    7 => 'Octavo',
                                                    8 => 'Noveno',
                                                    9 => 'Décimo'
                                                ];
                                            ?>

                                            <?php $__currentLoopData = $semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(isset($subject->semester)): ?>
                                                    <option value="<?php echo e($key); ?>" <?php echo e(($subject->semester == $key) ? 'selected' : ''); ?>><?php echo e($nombre); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($nombre); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            </div>

                            <div class="row">
                                <!-- Aula / Programa -->
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="classroom" class="col-sm-3 col-form-label">Aula</label>
                                        <div class="col-sm-9">
                                            <select id="classroom" name="classroom" class="form-control form-control-sm" data-dependent='subject'>
                                                <option value="0">Seleccione un Aula</option>
                                                <?php if(isset($subject)): ?>
                                                    <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($classroom->id); ?>" <?php echo e(($subject->classroom->id== $classroom->id)? 'selected': ''); ?>>
                                                            <?php echo e($classroom->name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($classroom->id); ?>"><?php echo e($classroom->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Docente -->
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="teacher" class="col-sm-3 col-form-label">Docente</label>
                                        <div class="col-sm-9">
                                            <select id="teacher" name="teacher" class="form-control form-control-sm">
                                                <option value="">Seleccione un Docente</option>
                                                <?php if(isset($subject)): ?>
                                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($teacher->id); ?>" <?php echo e((isset($subject->teacher) && $subject->teacher->id== $teacher->id)? 'selected': ''); ?>>
                                                            <?php echo e($teacher->first_name.' '.$teacher->surname); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($teacher->id); ?>"><?php echo e($teacher->first_name.' '.$teacher->surname); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <?php echo e(csrf_field()); ?>

                            </div>

                            <!-- Descripción -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label for="myTextarea" class="col-sm-2 col-form-label">Descripción</label>
                                        <div class="col-sm-10">
                                            <textarea type="text" style="resize: vertical;" rows="3" class="form-control" name="description"
                                                      id="myTextarea"><?php echo e(isset($subject)? $subject->description : old('description')); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Botones -->
                            <button type="submit" class="btn btn-primary me-2">Save</button>
                            <a class="btn btn-light" href="/subject">Cancel</a>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gestion1\resources\views/subject/view.blade.php ENDPATH**/ ?>