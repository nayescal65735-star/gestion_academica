;

<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-md-10 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e(isset($student)? 'Edit': 'Agregar nuevo'); ?> Estudiante <?php echo e(isset($student)? 'with The Number: '.$student->student_num: ''); ?></h4>
                            <p class="card-description">

                            </p>
                            <form class="forms-sample" action="<?php echo e(isset($student) ? '/student/update/'.$student->id : '/student/store'); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="first_name" class="col-sm-3 col-form-label">Primer Nombre</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" name="first_name" id="first_name" autofocus
                                                       placeholder="First Name" value="<?php echo e(isset($student)? $student->first_name: old('first_name')); ?>">
                                                <?php if($errors->has('first_name')): ?>
                                                    <div class="alert alert-danger">
                                                        <?php echo e($errors->first('first_name')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="surname" class="col-sm-3 col-form-label">Apellidos</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" name="surname" id="surname"
                                                       placeholder="Last Name" value="<?php echo e(isset($student)? $student->surname: old('surname')); ?>">
                                                <?php if($errors->has('surname')): ?>
                                                    <div class="alert alert-danger">
                                                        <?php echo e($errors->first('surname')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="gender" class="col-sm-3 col-form-label">Genero</label>
                                            <div class="col-sm-9">
                                                <select id="gender" name="gender" class="form-control form-control-sm">
                                                    <?php if(isset($student->gender)): ?>
                                                        <option value="0" <?php echo e(($student->gender == 0)? 'selected': ''); ?>>Masculino</option>
                                                        <option value="1" <?php echo e(($student->gender == 1)? 'selected': ''); ?>>Femenino</option>
                                                    <?php else: ?>
                                                        <option value="0">Masculino</option>
                                                        <option value="1">Femenino</option>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="birth_date" class="col-sm-3 col-form-label">Fecha de Nacimiento</label>
                                            <div class="col-sm-9">
                                                <input type="date" class="form-control" name="birth_date" id="birth_date"
                                                       placeholder="dd/mm/yyyy" value="<?php echo e(isset($student)? $student->birth_date: old('birth_date')); ?>">
                                                <?php if($errors->has('birth_date')): ?>
                                                    <div class="alert alert-danger">
                                                        <?php echo e($errors->first('birth_date')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="classroom" class="col-sm-3 col-form-label">Aula</label>
                                            <div class="col-sm-9">
                                                <select id="classroom" name="classroom" class="form-control form-control-sm">
                                                    <option value="">Seleccione un Aula</option>
                                                    <?php if(isset($student)): ?>
                                                        <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($classroom->id); ?>" <?php echo e(($student->classroom_id==$classroom->id)?
                                                        'selected': ''); ?>><?php echo e($classroom->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($classroom->id); ?>"><?php echo e($classroom->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="enrollment_date" class="col-sm-3 col-form-label">Fecha de Inscripción</label>
                                            <div class="col-sm-9">
                                                <input type="date" class="form-control" name="enrollment_date" id="enrollment_date"
                                                       placeholder="dd/mm/yyyy" value="<?php echo e(isset($student)? $student->enrollment_date: old('enrollment_date')); ?>">
                                                <?php if($errors->has('enrollment_date')): ?>
                                                    <div class="alert alert-danger">
                                                        <?php echo e($errors->first('enrollment_date')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php echo e(csrf_field()); ?>

                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="parent_phone_number" class="col-sm-3 col-form-label">Teléfono principal </label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" name="parent_phone_number" id="parent_phone_number"
                                                       placeholder="Enter Phone Number like *** *** ** **" value="<?php echo e(isset($student)? $student->parent_phone_number: old('parent_phone_number')); ?>">
                                                <?php if($errors->has('parent_phone_number')): ?>
                                                    <div class="alert alert-danger">
                                                        <?php echo e($errors->first('parent_phone_number')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group row">
                                            <label for="second_phone_number" class="col-sm-3 col-form-label">telefono segundario</label>
                                            <div class="col-sm-9">
                                                <input type="text" class="form-control" name="second_phone_number" id="second_phone_number"
                                                       placeholder="Phone Number" value="<?php echo e(isset($student)? $student->second_phone_number: old('second_phone_number')); ?>">
                                                <?php if($errors->has('second_phone_number')): ?>
                                                    <div class="alert alert-danger">
                                                        <?php echo e($errors->first('second_phone_number')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group row">
                                            <label for="address" class="col-sm-1 col-form-label">Address</label>
                                            <div class="col-sm-11">
                                                <textarea type="text" style="resize: vertical;" rows="3" class="form-control" name="address" id="address"
                                                          placeholder="Address"><?php echo e(isset($student)? $student->address: old('address')); ?></textarea>
                                                <?php if($errors->has('address')): ?>
                                                    <div class="alert alert-danger">
                                                        <?php echo e($errors->first('address')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary me-2">Save</button>
                                <a class="btn btn-light" href="/student">Cancel</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gestion1\resources\views/student/view.blade.php ENDPATH**/ ?>