;

<?php $__env->startSection('content'); ?>
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-10 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e(isset($classroom) ? 'Editar Aula' : 'Agregar Nueva Aula'); ?></h4>
                        <p class="card-description">
                            
                        </p>
                        <form class="forms-sample" action="<?php echo e(isset($classroom) ? '/classroom/update/'.$classroom->id : '/classroom/store'); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-3 col-form-label">Nombre</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="name" id="name" autofocus
                                                   placeholder="Nombre" value="<?php echo e(isset($classroom)? $classroom->name: old('name')); ?>">
                                            <?php if($errors->has('name')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('name')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label for="myTextarea" class="col-sm-2 col-form-label">Descripción</label>
                                        <div class="col-sm-10">
                                            <textarea type="text" rows="3" class="form-control" name="description" placeholder="Descripción"
                                                      id="myTextarea"><?php echo e(isset($classroom)? $classroom->description : old('description')); ?></textarea>
                                            <?php if($errors->has('description')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e($errors->first('description')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary me-2">Guardar</button>
                            <a class="btn btn-light" href="/classroom">Cancelar</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\gestion1\resources\views/classroom/view.blade.php ENDPATH**/ ?>