<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>{{ config('app.name', 'Laravel') }}</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
    <link rel="stylesheet" href="{{asset('/vendors/base/vendor.bundle.base.css')}}">
    <script
        src="https://code.jquery.com/jquery-3.6.0.slim.min.js"
        integrity="sha256-u7e5khyithlIdTpu22PHhENmPcRdFiHRjhAuHcs05RI="
        crossorigin="anonymous"></script>
    <!-- endinject -->
    <!-- inject:css -->
    <link rel="stylesheet" href="{{asset('/css/style.css')}}">
    <!-- endinject -->
    <link rel="shortcut icon" href="{{asset('/images/favicon.png')}}"/>
</head>
<body>
<div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
<div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">

    <!-- Logo principal (versión grande) -->
    <a class="navbar-brand brand-logo me-5 d-flex align-items-center" href="/">
        <img src="{{ asset('images/dashboard/LOGO.png') }}" 
             alt="logo" class="me-2" style="height: 45px;">

        <span style="
            font-size: 1.4rem; 
            font-weight: 800;
            background: linear-gradient(90deg, 
                        #64B5F6 0%,       /* azul vivo */
                        #A5D6F9 35%,      /* celeste claro */
                        #C1A3C9 100%);    /* morado pastel */
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.15);
        ">
            ACADEMIX
        </span>
    </a>

    <!-- Logo versión mini (sidebar cerrado) -->
    <a class="navbar-brand brand-logo-mini" href="/">
        <img src="{{ asset('images/logo_academico.png') }}" 
             alt="logo" style="height: 30px;">
    </a>

</div>


        <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
            <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
                <span class="ti-view-list"></span>
            </button>
            <ul class="navbar-nav mr-lg-2">
{{--                <li class="nav-item nav-search d-none d-lg-block">
                    <div class="input-group">
                        <div class="input-group-prepend hover-cursor" id="navbar-search-icon">
                <span class="input-group-text" id="search">
                 <i class="ti-search"></i>
                </span>
                        </div>
                        <input type="text" class="form-control" id="navbar-search-input" placeholder="Search now"
                               aria-label="search" aria-describedby="search">
                    </div>
                </li>--}}
            </ul>
            <ul class="navbar-nav navbar-nav-right">
{{--                <li class="nav-item dropdown me-1">
                    <a class="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center"
                       id="messageDropdown" href="#" data-bs-toggle="dropdown">
                        <i class="ti-email mx-0"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="messageDropdown">
                        <p class="mb-0 font-weight-normal float-left dropdown-header">Messages</p>
                        <a class="dropdown-item">
                            <div class="item-thumbnail">
                                <img src="images/faces/face4.jpg" alt="image" class="profile-pic">
                            </div>
                            <div class="item-content flex-grow">
                                <h6 class="ellipsis font-weight-normal">David Grey
                                </h6>
                                <p class="font-weight-light small-text text-muted mb-0">
                                    The meeting is cancelled
                                </p>
                            </div>
                        </a>
                        <a class="dropdown-item">
                            <div class="item-thumbnail">
                                <img src="images/faces/face2.jpg" alt="image" class="profile-pic">
                            </div>
                            <div class="item-content flex-grow">
                                <h6 class="ellipsis font-weight-normal">Tim Cook
                                </h6>
                                <p class="font-weight-light small-text text-muted mb-0">
                                    New product launch
                                </p>
                            </div>
                        </a>
                        <a class="dropdown-item">
                            <div class="item-thumbnail">
                                <img src="images/faces/face3.jpg" alt="image" class="profile-pic">
                            </div>
                            <div class="item-content flex-grow">
                                <h6 class="ellipsis font-weight-normal"> Johnson
                                </h6>
                                <p class="font-weight-light small-text text-muted mb-0">
                                    Upcoming board meeting
                                </p>
                            </div>
                        </a>
                    </div>
                </li>--}}
{{--                <li class="nav-item dropdown">
                    <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#"
                       data-bs-toggle="dropdown">
                        <i class="ti-bell mx-0"></i>
                        <span class="count"></span>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right navbar-dropdown"
                         aria-labelledby="notificationDropdown">
                        <p class="mb-0 font-weight-normal float-left dropdown-header">Notifications</p>
                        <a class="dropdown-item">
                            <div class="item-thumbnail">
                                <div class="item-icon bg-success">
                                    <i class="ti-info-alt mx-0"></i>
                                </div>
                            </div>
                            <div class="item-content">
                                <h6 class="font-weight-normal">Application Error</h6>
                                <p class="font-weight-light small-text mb-0 text-muted">
                                    Just now
                                </p>
                            </div>
                        </a>
                        <a class="dropdown-item">
                            <div class="item-thumbnail">
                                <div class="item-icon bg-warning">
                                    <i class="ti-settings mx-0"></i>
                                </div>
                            </div>
                            <div class="item-content">
                                <h6 class="font-weight-normal">Settings</h6>
                                <p class="font-weight-light small-text mb-0 text-muted">
                                    Private message
                                </p>
                            </div>
                        </a>
                        <a class="dropdown-item">
                            <div class="item-thumbnail">
                                <div class="item-icon bg-info">
                                    <i class="ti-user mx-0"></i>
                                </div>
                            </div>
                            <div class="item-content">
                                <h6 class="font-weight-normal">New user registration</h6>
                                <p class="font-weight-light small-text mb-0 text-muted">
                                    2 days ago
                                </p>
                            </div>
                        </a>
                    </div>
                </li>--}}
                <li class="nav-item nav-profile dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                         {{auth()->user()->name}}
                        <img src="{{url('/images/'.auth()->user()->photo_path)}}" alt="profile"/>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                        <!-- Authentication -->
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <a class="dropdown-item" href="route('logout')"
                                                   onclick="event.preventDefault();
                                        this.closest('form').submit();">
                                <i class="ti-power-off">
                                {{ __('Cerrar session') }}</i>
                            </a>
                        </form>
                    </div>
                </li>
            </ul>
            <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
                    data-toggle="offcanvas">
                <span class="ti-view-list"></span>
            </button>
        </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
        <!-- partial:partials -->
       <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="/">
                <i class="ti-shield menu-icon"></i>
                <span class="menu-title">Panel de control</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-classroom" aria-expanded="false"
               aria-controls="ui-classroom">
                <i class="ti-menu-alt menu-icon"></i>
                <span class="menu-title">Gestión de Aulas</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-classroom">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"><a class="nav-link" href="/classroom/create">Añadir nueva aula</a></li>
                    <li class="nav-item"><a class="nav-link" href="/classroom">Administrar Aulas</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-teacher" aria-expanded="false"
               aria-controls="ui-teacher">
                <i class="ti-briefcase menu-icon"></i>
                <span class="menu-title">Gestión de Docentes</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-teacher">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"><a class="nav-link" href="/teacher/create">Añadir Docente</a></li>
                    <li class="nav-item">
                        <a class="nav-link" href="/teacher">Administrar Docentes</a>
                    </li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-student" aria-expanded="false"
               aria-controls="ui-student">
                <i class="ti-id-badge menu-icon"></i>
                <span class="menu-title">Gestión de Estudiantes</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-student">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"><a class="nav-link" href="/student/create">Añadir Estudiante</a></li>
                    <li class="nav-item"><a class="nav-link" href="/student">Administrar Estudiantes</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-subject" aria-expanded="false"
               aria-controls="ui-subject">
                <i class="ti-ruler-pencil menu-icon"></i>
                <span class="menu-title">Gestión de Asignaturas</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-subject">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"><a class="nav-link" href="/subject/create">Añadir Asignatura</a></li>
                    <li class="nav-item"><a class="nav-link" href="/subject">Administrar Asignaturas</a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#users" aria-expanded="false"
               aria-controls="users">
                <i class="ti-user menu-icon"></i>
                <span class="menu-title">Gestión de Usuarios</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="users">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"><a class="nav-link" href="/manager/create">Añadir Usuario</a></li>
                    <li class="nav-item"><a class="nav-link" href="/manager">Administrar Usuarios</a></li>
                </ul>
            </div>
        </li>
    </ul>
</nav>

        <!-- partial -->

        @yield('content')

        <!-- main-panel ends -->

    </div>
    <!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->

<style>

/* ========================
   PALETA DE COLORES
   ======================== */
:root {
    --celeste-fondo: #E0F7FA;          /* Fondo general */
    --celeste-boton: #4FC3F7;          /* Botones principales */
    --celeste-boton-hover: #039BE5;    /* Hover de botones */
    --azul-activo: #0288D1;            /* Botón seleccionado */
    --celeste-gestion: #B3E5FC;        /* Fondo de gestión de submenús */
    --azul-oscuro: #01579B;            /* Texto importante y títulos */
    --blanco: #FFFFFF;                 /* Texto claro */
}

/* ========================
   NAVBAR SUPERIOR
   ======================== */
.navbar {
    background: var(--celeste-fondo);
    box-shadow: 0 3px 8px rgba(0,0,0,0.15);
}

/* Toggler */


/* ========================
   SIDEBAR
   ======================== */
.sidebar {
    background: var(--celeste-fondo);
    border-right: 2px solid rgba(0,0,0,0.1);
}

/* Botones principales del menú */
.sidebar .nav .nav-item .nav-link {
    color: var(--azul-oscuro);
    font-weight: 600;
    border-radius: 8px;
    margin: 4px 6px;
    padding: 8px 12px;
    transition: all 0.3s;
    background: var(--celeste-gestion);
}

/* Hover de los botones del menú */
.sidebar .nav .nav-item .nav-link:hover {
    background: var(--celeste-boton-hover);
    color: var(--blanco);
    transform: translateX(3px);
}

/* Submenú */
.sidebar .sub-menu {
    background: transparent; /* Transparente, igual que el fondo general */
    border-radius: 0;
    margin-left: 0;
    padding: 0;
}

.sidebar .sub-menu .nav-item .nav-link {
    color: var(--azul-oscuro);        /* Solo texto visible */
    background: transparent;           /* Sin fondo */
    margin-left: 20px;                 /* Sangría */
    padding: 6px 12px;
}

.sidebar .sub-menu .nav-item .nav-link:hover {
    background: var(--celeste-boton-hover);
    color: var(--blanco);
}

/* Elemento activo del sidebar */
.sidebar .nav .nav-item .nav-link.active,
.sidebar .sub-menu .nav-item .nav-link.active {
    background: var(--azul-activo);
    color: var(--blanco);
}

/* ========================
   BOTONES PRINCIPALES
   ======================== */
.btn {
    border-radius: 12px;
    font-weight: 600;
    padding: 10px 16px;
    border: none;
    cursor: pointer;
    transition: all 0.3s;
}

/* Botón celeste principal */
.btn-primary {
    background: var(--celeste-boton);
    color: var(--blanco);
    box-shadow: 0 4px 10px rgba(0,123,255,0.3);
}
.btn-primary:hover {
    background: var(--celeste-boton-hover);
    transform: translateY(-2px);
}

/* Botón celeste secundario */
.btn-celeste {
    background: var(--celeste-gestion);
    color: var(--azul-oscuro);
    box-shadow: 0 4px 10px rgba(135,206,250,0.5);
}
.btn-celeste:hover {
    background: var(--celeste-boton-hover);
    color: var(--blanco);
    transform: translateY(-2px);
}

/* ========================
   TARJETAS / CUERPO
   ======================== */
.card {
    border-radius: 16px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.12);
    border: none;
    background: var(--celeste-fondo);
    transition: all 0.3s;
}

.card:hover {
    box-shadow: 0 6px 16px rgba(0,0,0,0.2);
    transform: translateY(-2px);
}

.card-title {
    color: var(--azul-oscuro);
    font-weight: 700;
}

.card-body {
    background: var(--celeste-fondo);
    border-radius: 16px;
}

/* ========================
   ÍCONOS
   ======================== */


/* ========================
   PERFIL (dropdown)
   ======================== */


/* ========================
   HOVERS Y EFECTOS
   ======================== */
a:hover {
    text-decoration: none;
    opacity: 0.9;
    transition: all 0.3s;
}

</style>



<!-- partial -->


<script type="text/javascript">
    $(function () {
        // Multiple images preview with JavaScript
        var multiImgPreview = function (input, imgPreviewPlaceholder) {
            if (imgPreviewPlaceholder.files) {
                imgPreviewPlaceholder.files.clear();
            }
            if (input.files) {
                var filesAmount = input.files.length;
                for (i = 0; i < filesAmount; i++) {
                    var reader = new FileReader();
                    reader.onload = function (event) {
                        var $clone = $($.parseHTML('<img>'));
                        $clone.attr('class', 'image_pr');
                        $clone.attr('style', 'max-width: 200px;');
                        $clone.attr('src', event.target.result).appendTo(imgPreviewPlaceholder);
                    }
                    reader.readAsDataURL(input.files[i]);

                }
            }
        };
        $('#images').on('change', function () {
            multiImgPreview(this, 'div.preview-image');
        });
        $('#photo').on('change', function () {
            // To delete the uploaded photo from preview after selecting new photo
            var arr = document.getElementsByClassName('image_pr');
            if (arr.length) {
                for (var i = 0; i < arr.length; i++) {
                    arr[i].remove();
                }
            }
            multiImgPreview(this, 'div.preview-image');
        });
    });

</script>
<!-- plugins:js -->

<script src="{{asset('vendors/base/vendor.bundle.base.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.9.1/chart.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.js" type="text/javascript"></script>

<!-- Custom js for dashboard-->
<script src="{{asset('js/off-canvas.js')}}"></script>
<script src="{{asset('js/hoverable-collapse.js')}}"></script>
<script src="{{asset('js/template.js')}}"></script>
<script src="{{asset('js/chart.js')}}"></script>
<script src="{{asset('js/file-upload.js')}}"></script>
<!-- End custom js for dashboard-->



</body>

</html>
