@extends('layouts.app_view');

@section('content')
<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Tabla de Aulas</h4>
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Nombre</th>
                                        <th>Descripción</th>
                                        {{-- <th>Estado de Ocupación</th> --}}
                                        <th>Cantidad de Estudiantes</th>
                                        <th>Acciones</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($classrooms as $classroom)
                                        <tr>
                                            <td class="py-1">
                                                {{$classroom->id}}
                                            </td>
                                            <td>
                                                {{$classroom->name}}
                                            </td>
                                            <td>
                                                {{$classroom->description}}
                                            </td>
                                            {{-- Todo: Agregar límite para las aulas y mostrar el estado de ocupación de cada una. --}}
                                            {{-- 
                                            <td>
                                                <div class="progress">
                                                    <div class="progress-bar bg-success" role="progressbar"
                                                         style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                                         aria-valuemax="100"></div>
                                                </div>
                                            </td> 
                                            --}}
                                            <td style="text-align: center">
                                                {{$classroom->students->count()}}
                                            </td>
                                            <td>
                                                <div class="btn-group">
                                                    <form action="/classroom/edit/{{ $classroom->id }}" method="get">
                                                        @csrf
                                                        <button type="submit" class="btn btn-dark ti-pencil-alt btn-rounded">
                                                            Editar
                                                        </button>
                                                    </form>
                                                    <form action="/classroom/delete/{{ $classroom->id }}" method="post">
                                                        @method('DELETE')
                                                        @csrf
                                                        <button onclick="return confirm('¿Está seguro de que desea eliminar esto?')" type="submit" class="btn btn-danger ti-trash btn-rounded">
                                                            Eliminar
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                        <div class="d-flex justify-content-center">
                            {!! $classrooms->links() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- content-wrapper ends -->
</div>


@endsection
