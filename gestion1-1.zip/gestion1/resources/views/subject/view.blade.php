@extends('layouts.app_view');

@section('content')
   <div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-10 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">
                            {{isset($subject)? 'Editar': 'Añadir Nueva'}} Asignatura 
                            {{isset($subject)? 'con el Código: '.$subject->subject_code: ''}}
                        </h4>
                        <p class="card-description"></p>

                        <form class="forms-sample" action="{{ isset($subject) ? '/subject/update/'.$subject->id : '/subject/store' }}" method="post">
                            @csrf
                            <div class="row">
                                <!-- Nombre de la asignatura -->
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="name" class="col-sm-3 col-form-label">Nombre</label>
                                        <div class="col-sm-9">
                                            <input type="text" class="form-control" name="name" id="name" autofocus
                                                   placeholder="Nombre" value="{{isset($subject)? $subject->name: old('name')}}">
                                        </div>
                                    </div>
                                </div>

                                <!-- Semestre -->
                            <div class="col-md-6">
                                <div class="form-group row">
                                    <label for="semester" class="col-sm-3 col-form-label">Semestre</label>
                                    <div class="col-sm-9">
                                        <select id="semester" name="semester" class="form-control form-control-sm">
                                            @php
                                                $semestres = [
                                                    0 => 'Primero',
                                                    1 => 'Segundo',
                                                    2 => 'Tercero',
                                                    3 => 'Cuarto',
                                                    4 => 'Quinto',
                                                    5 => 'Sexto',
                                                    6 => 'Séptimo',
                                                    7 => 'Octavo',
                                                    8 => 'Noveno',
                                                    9 => 'Décimo'
                                                ];
                                            @endphp

                                            @foreach($semestres as $key => $nombre)
                                                @if(isset($subject->semester))
                                                    <option value="{{ $key }}" {{ ($subject->semester == $key) ? 'selected' : '' }}>{{ $nombre }}</option>
                                                @else
                                                    <option value="{{ $key }}">{{ $nombre }}</option>
                                                @endif
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>

                            </div>

                            <div class="row">
                                <!-- Aula / Programa -->
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="classroom" class="col-sm-3 col-form-label">Aula</label>
                                        <div class="col-sm-9">
                                            <select id="classroom" name="classroom" class="form-control form-control-sm" data-dependent='subject'>
                                                <option value="0">Seleccione un Aula</option>
                                                @if(isset($subject))
                                                    @foreach($classrooms as $classroom)
                                                        <option value="{{$classroom->id}}" {{($subject->classroom->id== $classroom->id)? 'selected': ''}}>
                                                            {{$classroom->name}}
                                                        </option>
                                                    @endforeach
                                                @else
                                                    @foreach($classrooms as $classroom)
                                                        <option value="{{$classroom->id}}">{{$classroom->name}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- Docente -->
                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="teacher" class="col-sm-3 col-form-label">Docente</label>
                                        <div class="col-sm-9">
                                            <select id="teacher" name="teacher" class="form-control form-control-sm">
                                                <option value="">Seleccione un Docente</option>
                                                @if(isset($subject))
                                                    @foreach($teachers as $teacher)
                                                        <option value="{{$teacher->id}}" {{(isset($subject->teacher) && $subject->teacher->id== $teacher->id)? 'selected': ''}}>
                                                            {{$teacher->first_name.' '.$teacher->surname}}
                                                        </option>
                                                    @endforeach
                                                @else
                                                    @foreach($teachers as $teacher)
                                                        <option value="{{$teacher->id}}">{{$teacher->first_name.' '.$teacher->surname}}</option>
                                                    @endforeach
                                                @endif
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                {{ csrf_field() }}
                            </div>

                            <!-- Descripción -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group row">
                                        <label for="myTextarea" class="col-sm-2 col-form-label">Descripción</label>
                                        <div class="col-sm-10">
                                            <textarea type="text" style="resize: vertical;" rows="3" class="form-control" name="description"
                                                      id="myTextarea">{{isset($subject)? $subject->description : old('description')}}</textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Botones -->
                            <button type="submit" class="btn btn-primary me-2">Save</button>
                            <a class="btn btn-light" href="/subject">Cancel</a>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection
